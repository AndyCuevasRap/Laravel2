<div>
    @include('livewire.create')
    @include('livewire.update')
    @include('livewire.delete')
    <section>
        <div class="container">
            <div class="row">
            @if (session()->has('message'))
                <div class="alert alert-success">
                    {{session('message')}}
                </div> 
                @endif
                <div class="card">
                    <div class="card-header">
                        <h3><center><i>
                            FBI (Informacion Victimas)
                            <!-- Button trigger modal -->
                        </h3></center></i>
                        <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addStudentModal"><i>
                                Añadir Victimas
                        </i></button>
                    </div>
                    <div class="card-body">
                        <table class="table tabl-striped">
                            <thead>
                                <tr>
                                    <th><i>Nombre</i></th>
                                    <th><i>Apellido</i></th>
                                    <th><i>Descripcion</i></th>
                                    <th><i>Lugar</i></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($victimas as $victima)
                                <tr>
                                    <td>{{$victima->nombre}}</td>
                                    <td>{{$victima->lastname}}</td>
                                    <td>{{$victima->email}}</td>
                                    <td>{{$victima->phone}}</td>
                                    <td>
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateStudentModal" wire:click.prevent="edit({{$student->id}})"><i>Editar</i></button>
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteStudentModal" wire:click.prevent="delete({{$student->id}})"><i>Eliminar</i></button>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>