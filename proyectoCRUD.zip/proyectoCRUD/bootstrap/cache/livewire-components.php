<?php return array (
  'students' => 'App\\Http\\Livewire\\Students',
);